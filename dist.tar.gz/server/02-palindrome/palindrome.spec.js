describe('a palindrome function', () => {
});
