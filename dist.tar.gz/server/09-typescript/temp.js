//var FooBar = (function () {
//    function FooBar() {
//        this.name = 'wil';
//    }
//    return FooBar;
//}());
