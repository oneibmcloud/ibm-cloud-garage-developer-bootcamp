describe('the canary spec', () => {
  it('shows the test infrastructure works', () => {
    true.should.be.true();
  });
});
