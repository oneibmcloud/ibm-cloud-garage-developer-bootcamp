describe('line count can be checked', () => {
  //const filespec = 'server/async-01-line-count-with-callback/line-count.js';

  it('with the done parameter like with a callback');

  it('by returning the promise after .then');

  it('by using eventually or fulfilledWith');
});
