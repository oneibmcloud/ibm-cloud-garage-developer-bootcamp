/*eslint dot-notation: "off"*/
//import {replace, when, verify} from '../../test-helper';

describe('unusual spending should', () => {
  it('canary test shows the infrastructure works', () => {
    true.should.be.true();
  });
});
