const realEmail = () => {};

export {realEmail};
