describe('line count', () => {
  it('for file —— line-count.js —— should be 13');

  it('for file —— is-not-there.js —— should be problem reading file: ' +
      'is-not-there.js');
});
