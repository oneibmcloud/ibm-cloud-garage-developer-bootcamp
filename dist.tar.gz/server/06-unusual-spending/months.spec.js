describe('months', () => {
  it('gives the current month');
  it('gives the prior month');
});
