export const categorize = () => {};
